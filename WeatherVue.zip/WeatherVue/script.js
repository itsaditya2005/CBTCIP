// Function to handle key press event for city input
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        getWeather();
    }
}

// Function to fetch weather data from API
async function getWeather() {
    const apiKey = 'Enter_Your_APIKEY_Here_To_Run_Project_Properly'; //This JavaScript optimized according to openweathermap.org data
    const city = document.getElementById('city').value.trim();
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('City not found');
        }
        const weatherData = await response.json();
        displayWeather(weatherData);
    } catch (error) {
        console.error('Error fetching weather data:', error);
        showDialog('City Not Found', 'Please enter a valid city name.');
    }
}

// Function to format date as dd/mm/yyyy
function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.getMonth() + 1; 
    const year = date.getFullYear();

    const formattedDay = (day < 10) ? `0${day}` : day;
    const formattedMonth = (month < 10) ? `0${month}` : month;

    return `${formattedDay}/${formattedMonth}/${year}`;
}

// Function to format time as hh:mm AM/PM
function formatTime(dateString) {
    const date = new Date(dateString);
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    const formattedTime = `${hours}:${minutes < 10 ? '0' + minutes : minutes} ${ampm}`;
    return formattedTime;
}

// Function to display weather details on the page
function displayWeather(weatherData) {
    document.getElementById('location').textContent = weatherData.name;

    const formattedDate = formatDate(new Date());
    document.getElementById('date').textContent = formattedDate;

    const formattedTime = formatTime(new Date());
    document.getElementById('time').textContent = formattedTime;

    document.getElementById('description').textContent = weatherData.weather[0].description;
    document.getElementById('temperature').textContent = `${weatherData.main.temp} °C`;
    document.getElementById('wind').textContent = `${weatherData.wind.speed} m/s`;
    document.getElementById('humidity').textContent = `${weatherData.main.humidity} %`;

    document.getElementById('weather-details').style.display = 'block';
}

// Function to show dialog box with custom message
function showDialog(title, message) {
    const dialogBox = document.createElement('div');
    dialogBox.className = 'dialog';
    dialogBox.innerHTML = `
        <div class="dialog-content">
            <h2>${title}</h2>
            <p>${message}</p>
            <button onclick="closeDialog()">OK</button>
        </div>
    `;
    document.body.appendChild(dialogBox);
}

// Function to close dialog box
function closeDialog() {
    const dialog = document.querySelector('.dialog');
    if (dialog) {
        dialog.remove();
    }
}
