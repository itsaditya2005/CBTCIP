document.addEventListener('DOMContentLoaded', () => {
    const newTaskInput = document.getElementById('new-task-input');
    const addTaskButton = document.getElementById('add-task-button');
    const tasksList = document.getElementById('tasks-list');
    const completedTasksList = document.getElementById('completed-tasks-list');
    const defaultRow = document.getElementById('default-row');
    const defaultCompletedRow = document.getElementById('default-completed-row');

    addTaskButton.addEventListener('click', addTask);
    newTaskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addTask();
    });

    function addTask() {
        const taskText = newTaskInput.value.trim();
        if (taskText === '') return;

        // Ask the user if they want to add a reminder
        const addReminder = confirm("Do you want to add a reminder for this task?");
        let reminderTime = null;
        if (addReminder) {
            const currentTime = new Date();
            const defaultTime = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
            reminderTime = prompt("Please enter the reminder time (HH:MM AM/PM, 12-hour format):", defaultTime);
            if (reminderTime) {
                scheduleReminder(taskText, reminderTime);
            }
        }

        // Remove the default row if it exists
        if (defaultRow && tasksList.contains(defaultRow)) {
            defaultRow.remove();
        }

        const currentDateTime = new Date();

        const row = document.createElement('tr');
        const taskCell = document.createElement('td');
        const dateAddedCell = document.createElement('td');
        const timeCell = document.createElement('td'); 
        const completeCell = document.createElement('td'); 
        const completeCheckbox = document.createElement('input');
        const actionCell = document.createElement('td'); 
        const deleteButton = document.createElement('button');

        taskCell.textContent = taskText;
        dateAddedCell.textContent = currentDateTime.toLocaleDateString();
        timeCell.textContent = currentDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }); // Display local time in 12-hour format
        completeCheckbox.type = 'checkbox'; 
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('delete-button');

        deleteButton.addEventListener('click', () => {
            row.remove();
            checkEmptyLists();
        });

        completeCheckbox.addEventListener('change', () => {
            if (completeCheckbox.checked) {
                taskCell.classList.add('completed');
                completeCheckbox.disabled = true; 
                completeCheckbox.classList.add('fade'); 
                moveToCompletedTasks(taskText, currentDateTime);
            }
        });

        completeCell.appendChild(completeCheckbox); 
        actionCell.appendChild(deleteButton); 
        row.appendChild(taskCell);
        row.appendChild(dateAddedCell);
        row.appendChild(timeCell);
        row.appendChild(completeCell); 
        row.appendChild(actionCell);
        tasksList.appendChild(row);

        newTaskInput.value = '';
        newTaskInput.focus();
    }

    function moveToCompletedTasks(taskText, addedDateTime) {
        // Remove the default completed row if it exists
        if (defaultCompletedRow && completedTasksList.contains(defaultCompletedRow)) {
            defaultCompletedRow.remove();
        }

        const completeDateTime = new Date();

        const row = document.createElement('tr');
        const taskCell = document.createElement('td');
        const completeDateCell = document.createElement('td');
        const completeTimeCell = document.createElement('td'); 
        const actionCell = document.createElement('td'); 
        const deleteButton = document.createElement('button');

        taskCell.textContent = taskText;
        completeDateCell.textContent = completeDateTime.toLocaleDateString(); 
        completeTimeCell.textContent = completeDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }); // Display local complete time in 12-hour format
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('delete-button');

        deleteButton.addEventListener('click', () => {
            row.remove();
            checkEmptyLists();
        });

        actionCell.appendChild(deleteButton); 
        row.appendChild(taskCell);
        row.appendChild(completeDateCell);
        row.appendChild(completeTimeCell); 
        row.appendChild(actionCell); 
        completedTasksList.appendChild(row);
        checkEmptyLists(); 
    }

    function scheduleReminder(taskText, reminderTime) {
        const [time, modifier] = reminderTime.split(' ');
        let [hours, minutes] = time.split(':');

        if (modifier === 'PM' && hours !== '12') {
            hours = parseInt(hours, 10) + 12;
        } else if (modifier === 'AM' && hours === '12') {
            hours = '00';
        }

        const now = new Date();
        const reminderDateTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes, 0);

        const timeDifference = reminderDateTime.getTime() - now.getTime();

        if (timeDifference > 0) {
            setTimeout(() => {
                alert(`Reminder: ${taskText}`);
            }, timeDifference);
        } else {
            alert('The reminder time has already passed.');
        }
    }

    function checkEmptyLists() {
        if (tasksList.children.length === 0) {
            tasksList.appendChild(defaultRow);
        }
        if (completedTasksList.children.length === 0) {
            completedTasksList.appendChild(defaultCompletedRow);
        }
    }
});
